struct coord
{
	byte x;
	byte y;
};
