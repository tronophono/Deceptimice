struct entry
{
	int distance;
	byte walls;
};
