/*
 * encoder.cpp
 *
 *  Created on: Jan 11, 2017
 *      Author: lasantos
 */

#include "Arduino.h"
#include "encoder.h"
#include "EnableInterrupt.h"



void Encoder::doEncoderRightA() {

  // look for a low-to-high on channel A
  if (digitalRead(encoder0PinA) == HIGH) {
    // check channel B to see which way encoder is turning
    if (digitalRead(encoder0PinB) == LOW) {
      encoderPos[0] = encoderPos[0] + 1;         // CW
    } else {
      encoderPos[0] = encoderPos[0] - 1;         // CCW
    }
  } else  // must be a high-to-low edge on channel A
  {
    // check channel B to see which way encoder is turning
    if (digitalRead(encoder0PinB) == HIGH) {
      encoderPos[0] = encoderPos[0] + 1;          // CW
    } else {
      encoderPos[0] = encoderPos[0] - 1;          // CCW
    }
  }
  if (encoderPos[0] >= 100000) {
    //stop_it();
    encoderPos[0] = 0;
  }
  // use for debugging - remember to comment out
}

void Encoder::doEncoderRightB() {

  // look for a low-to-high on channel B
  if (digitalRead(encoder0PinB) == HIGH) {
    // check channel A to see which way encoder is turning
    if (digitalRead(encoder0PinA) == HIGH) {
      encoderPos[0] = encoderPos[0] + 1;         // CW
    } else {
      encoderPos[0] = encoderPos[0] - 1;         // CCW
    }
  }
  // Look for a high-to-low on channel B
  else {
    // check channel B to see which way encoder is turning
    if (digitalRead(encoder0PinA) == LOW) {
      encoderPos[0] = encoderPos[0] + 1;          // CW
    } else {
      encoderPos[0] = encoderPos[0] - 1;          // CCW
    }
  }
  if (encoderPos[0] >= 100000) {
    //stop_it();
    encoderPos[0] = 0;
  }
}

//This is the functions that takes care of the count of the encoders left

void Encoder::doEncoderLeftA() {

  // look for a low-to-high on channel A
  if (digitalRead(encoder1PinA) == HIGH) {
    // check channel B to see which way encoder is turning
    if (digitalRead(encoder1PinB) == LOW) {
      encoderPos[1] = encoderPos[1] - 1;         // CW
    } else {
      encoderPos[1] = encoderPos[1] + 1;         // CCW
    }
  } else  // must be a high-to-low edge on channel A
  {
    // check channel B to see which way encoder is turning
    if (digitalRead(encoder1PinB) == HIGH) {
      encoderPos[1] = encoderPos[1] - 1;          // CW
    } else {
      encoderPos[1] = encoderPos[1] + 1;          // CCW
    }
  }

  // use for debugging - remember to comment out
}

void Encoder::doEncoderLeftB() {

  // look for a low-to-high on channel B
  if (digitalRead(encoder1PinB) == HIGH) {
    // check channel A to see which way encoder is turning
    if (digitalRead(encoder1PinA) == HIGH) {
      encoderPos[1] = encoderPos[1] - 1;         // CW
    } else {
      encoderPos[1] = encoderPos[1] + 1;         // CCW
    }
  }
  // Look for a high-to-low on channel B
  else {
    // check channel B to see which way encoder is turning
    if (digitalRead(encoder1PinA) == LOW) {
      encoderPos[1] = encoderPos[1] - 1;          // CW
    } else {
      encoderPos[1] = encoderPos[1] + 1;          // CCW
    }
  }
}

void Encoder::SetPins(){

  pinMode(encoder0PinA, INPUT);
  pinMode(encoder0PinB, INPUT);

  enableInterrupt(encoder0PinA, doEncoderRightA, CHANGE);
  enableInterrupt(encoder0PinB, doEncoderRightB, CHANGE);

  pinMode(encoder1PinA, INPUT);
  pinMode(encoder1PinB, INPUT);

  enableInterrupt(encoder1PinA, doEncoderLeftA, CHANGE);
  enableInterrupt(encoder1PinB, doEncoderLeftB, CHANGE);
}
//Set up pins for encoder (right,right, left, left)
Encoder::Encoder(byte encoder0PA, byte encoder0PB, byte encoder1PA, byte encoder1PB) {

  encoder0PinA = encoder0PA;
  encoder0PinB = encoder0PB;


  encoder1PinA = encoder1PA;
  encoder1PinB = encoder1PB;

  SetPins();

}

void Encoder::printEncoderValues() {
  Serial.print("Right Encoder: ");
  Serial.println(encoderPos[0]);
  Serial.print("Left Encoder: ");
  Serial.println(encoderPos[1]);
}

