/*
 * encoder.h
 *
 *  Created on: Jan 11, 2017
 *      Author: lasantos
 */


#ifndef ENCODER_H_
#define ENCODER_H_

#include "Arduino.h"
#include "EnableInterrupt.h"

class Encoder{
 public: 
  volatile long encoderPos[1];
  byte encoder0PinA;
  byte encoder0PinB;
  byte encoder1PinA;
  byte encoder1PinB;

  Encoder(byte encoder0PA, byte encoder0PB, byte encoder1PA, byte encoder1PB);
  void doEncoderRightA();
  void doEncoderRightB();
  void doEncoderLeftA();
  void doEncoderLeftB();
  void printEncoderValues();
  void SetPins();

};


#endif /* ENCODER_H_ */
